document.writeln("<script type=\"text/javascript\" src=\"/g/template/jelly/js/jquery.js\"></script>");
document.writeln("<script type=\"text/javascript\" src=\"/g/template/jelly/js/jquery.lazyload.min.js\"></script>");
document.writeln("<script type=\"text/javascript\" src=\"/g/template/jelly/js/common.js?v=20190609\"></script>");
document.writeln("<script type=\"text/javascript\" src=\"/g/template/jelly/js/scorll.js?v=20190609\"></script>");